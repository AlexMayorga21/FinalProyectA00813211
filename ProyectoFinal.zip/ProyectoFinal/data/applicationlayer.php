<?php

header('Content-type: application/json');
require_once __DIR__ . '/dataLayer.php';

$action = $_POST["action"];

switch($action){
    case "LOGIN" : loginFunction();
        break;
    case "STORY" : postStory();
        break;
    case "REGISTER" : registerFunction();
        break;
    case "LOAD" : loadComments();
        break;
    case "CHECKSESSION" : checkSessions();
        break;
    case "CHECKCOOKIE" : checkCookie();
        break;
    case "COMMENT" : addComment();
        break;
    case "TOP" : TopTen();
        break;
    case "VOTE" : VoteCategory();
        break;
    case "USER" : GetUser();
        break;
    case "FAV" :ChoseFavorite();
        break;
    case "LOADFAVS": loadFavorites();
        break;
    default : logOut();
}

function loadFavorites() {
    $results = attemptLoadFavorites();
    if (sizeof($results) > 0){
        echo json_encode($results);
    } else {
        header("HTTP/1.1 Could not load the comments.");
        die("It was not possible to load the comments");
    }
}

function GetUser(){
    $result = attemptGetUser();
    if (sizeof($result) > 0){
        echo json_encode($result);
    } else {
        header("HTTP/1.1 Could not load the user info.");
        die("It was not possible to load the user info.");
    }
}

function ChoseFavorite() {
    $name = $_POST['name'];
    $result = attemptFavorite($name);
    if ($result['status'] == "SUCCESS"){
        echo json_encode(array("message"=>"New favorite added"));
    }
    else if($result['status'] == "ALREADYIN") {
        echo json_encode(array("message"=>"This is already in your favorites!"));
    }
    else {
        header("HTTP/1.1 " . $result['status']);
        die($result['status']);
    }
}

function VoteCategory() {
    $Category = $_POST['category'];
    $Nombre = $_POST['nombre'];
    $result = attemptVoteCategory($Category,$Nombre);
    if ($result['status'] == "SUCCESS"){
        echo json_encode(array("message"=>"you voted for " + $Category));
    } else {
        header("HTTP/1.1 " . $result['status']);
        die($result['status']);
    }

}
function TopTen() {
    $Category = $_POST['category'];
    $results = attemptTopTen($Category);

    if (sizeof($results) > 0){
        echo json_encode($results);
    } else {
        header("HTTP/1.1 Could not load the top 10.");
        die("It was not possible to load the top 10.");
    }
}

function postStory()
{
    session_start();
    if (isset($_POST['session'])){
        $email = $_SESSION['email'];
        $pass = $_SESSION['password'];
    }
    else
    {
        $email = $_POST['email'];
        $pass = $_POST['password'];
    }
    $result = attemptAddStory($email, $pass);
    if ($result['status'] == "SUCCESS"){
        echo json_encode(array("message"=>"Story posted successfully","email" =>$result['email']));
    } else {
        header("HTTP/1.1 " . $result['status']);
        die($result['status']);
    }
}

function encryptPassword($pass)
{

    $key = pack('H*', "bcb04b7e103a05afe34763051cef08bc55abe029fdebae5e1d417e2ffb2a00a3");
    $key_size =  strlen($key);

    $plaintext = $pass;

    $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);

    $ciphertext = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $plaintext, MCRYPT_MODE_CBC, $iv);
    $ciphertext = $iv . $ciphertext;

    $userPassword = base64_encode($ciphertext);

    return $userPassword;
}




function loginFunction(){
    $userName = $_POST["email"];
    $userPassword = $_POST["password"];
    $remember = $_POST['recordar'];

    $result = attemptLogin($userName, $userPassword, $remember);

    if ($result["status"] == "SUCCESS"){
        echo json_encode($result);
    }
    else{
        header('HTTP/1.1 500' . $result["status"]);
        die($result["status"]);
    }
}

function registerFunction() {
    $email = $_POST["email"];
    $userPassword = $_POST["password"];
    $fname = $_POST["fName"];
    $lname = $_POST["lName"];
    $username = $_POST['username'];

    $result = attemptRegister($email, $fname, $lname, encryptPassword($userPassword), $username );

    if ($result['status'] == "SUCCESS"){
        echo json_encode(array("message"=>"Successfully registered."));
    } else {
        if ($result['status'] == "ALREADYIN"){
            echo json_encode(array("message"=>"An account was registered with this email", "user_exists"=>"1"));
        } else {
            header("HTTP/1.1 " . $result['status']);
            die($result['status']);
        }
    }
}

function addComment(){
    session_start();

    if (isset($_POST['session'])){
        $email = $_SESSION['userName'];
        $pass = $_SESSION['password'];
    }
    else
        {
            $email = $_POST['email'];
            $pass = $_POST['password'];
        }
    $result = attemptAddComment($email, $pass);
    if ($result['status'] == "SUCCESS"){
        echo json_encode(array("message"=>"Comment posted successfully","email" =>$result['email']));
    } else {
        header("HTTP/1.1 " . $result['status']);
        die($result['status']);
    }
}

function loadComments() {
    $results = attemptLoadComments();

    if (sizeof($results) > 0){
        echo json_encode($results);
    } else {
        header("HTTP/1.1 Could not load the comments.");
        die("It was not possible to load the comments");
    }
}

function checkSessions() {
    session_start();
    if(isset($_SESSION["fname"])&& isset($_SESSION["lname"]) && isset($_SESSION["email"])){
        $result = array("fname"=>$_SESSION["fname"],"lname" =>$_SESSION["lname"], "userName"=>$_SESSION["email"]);
        echo  json_encode($result); // Session exists
    }
 else {
    echo '0'; // Session does not exist
}
session_write_close();
}

function checkCookie(){
    if (isset($_COOKIE['Email'])){
        $response = array("Cookie"=>$_COOKIE['Email']);
        echo json_encode($response); // Cookie stored
    } else {
        echo '0'; // Session does not exist
    }
}

function logOut() {
    session_start();
    unset($_SESSION["fname"]);
    unset($_SESSION["lname"]);
    unset($_SESSION["userName"]);
    session_destroy();
    header("Location: ../index.html");
    die();
}
?>