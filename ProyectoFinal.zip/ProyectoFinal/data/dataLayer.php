<?php
/**
 * Created by PhpStorm.
 * User: DI_GO
 * Date: 01/11/2016
 * Time: 08:21 PM
 */


function connectionToDataBase() {
    $servername = "127.0.0.1";
    $username = "root";
    $password = "";
    $dbname = "longstoryshort";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if($conn->connect_error) {
        return null;
    } else {
        return $conn;
    }
}

function decryptPassword($pass)
{
    $key = pack('H*', "bcb04b7e103a05afe34763051cef08bc55abe029fdebae5e1d417e2ffb2a00a3");

    $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);

    $ciphertext_dec = base64_decode($pass);
    $iv_dec = substr($ciphertext_dec, 0, $iv_size);
    $ciphertext_dec = substr($ciphertext_dec, $iv_size);


    $pass = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, $ciphertext_dec, MCRYPT_MODE_CBC, $iv_dec);

    $count = 0;
    $length = strlen($pass);

    for ($i = $length - 1; $i >= 0; $i --)
    {
        if (ord($pass{$i}) === 0)
        {
            $count ++;
        }
    }

    $pass = substr($pass, 0,  $length - $count);

    return $pass;
}


function attemptLogin($userName, $pssword, $remember) {
    $conn = connectionToDataBase();
    if($conn != null){
        $sql = "SELECT * FROM users WHERE email = '$userName'";

        $result = $conn ->query($sql);

        if($result -> num_rows > 0) {
            //
            $row = $result->fetch_assoc();
            if(decryptPassword($row['passwrd'])==$pssword) {
                session_start();
                $_SESSION["fname"] = $row["fname"];
                $_SESSION["lname"] = $row["lname"];
                $_SESSION["email"] = $row["email"];
                $_SESSION["password"] = $pssword;

                if ($remember === true) {
                    setcookie("Email", $row["email"], time() + 1728000);
                }

                $conn->close();
                return array("status" => "SUCCESS", "fname" => $row["fname"], "lname" => $row["lname"]);
            }  else {
            $conn->close();
            return array("status"=>'INCORRECT PASSWORD');
        }} else {
            $conn -> close();
            return array("status" =>"USER NOT FOUND");
        }
    } else {
        $conn->close();
        return array("status" => "COULD NOT CONNECT TO DATABASE");
    }
}

function attemptRegister($email, $fname, $lname, $pssword, $userName) {
    $conn = connectionToDataBase();
    if($conn != null){
        $sql = "SELECT * FROM users WHERE email = '$email'";
        $result = $conn->query($sql);
        if($result->num_rows > 0) {
            $conn->close();
            return array("status"=>"ALREADYIN");
        } else {
            $sql = "INSERT INTO Users (fname, lname, email, passwrd,username) VALUES ('$fname','$lname','$email','$pssword','$userName')";

            if(mysqli_query($conn,$sql))
            {
                $conn ->close();
                return array("status" => "SUCCESS");
            }
            else
            {
                $conn->close();
                return array("status" => "COULD NOT REGISTER USER");
            }
        }
    } else {
        $conn ->close();
        return array("status" => "COULD NOT CONNECT  TO DATABASE");
    }
}

function attemptFavorite() {
    $conn = connectionToDataBase();
    if($conn != null) {
        $name = $_POST['name'];
        $sql1 = "SELECT storyid FROM stories WHERE storyname = '$name'";
        $result1 = $conn->query($sql1);
        if($result1->num_rows > 0) {
            $row = $result1->fetch_assoc();
            $storyId = $row["storyid"];
            session_start();
            $emailFK = $_SESSION['email'];
            $sql3 = "SELECT * FROM favorites WHERE emailFK ='$emailFK' AND storyidFK = '$storyId'";
            $result3 = $conn->query($sql3);
            if($result3->num_rows > 0) {
                return array("status" => "ALREADYIN");
            }
            else {
                $sql2 = "INSERT INTO favorites (emailFK, storyidFK)
VALUES ('$emailFK','$storyId')";
                if (mysqli_query($conn, $sql2)) {
                    $conn->close();
                    return array("status" => "SUCCESS");
                } else {
                    $conn->close();
                    return array("status" => "IT WAS NOT POSSIBLE TO ADD FAVORITE");
                }
            }
        }
        else {
            $conn->close();
            return array("status"=>"COULD NOT CONNECT TO DATABASE");
        }
    }
}


function attemptLoadFavorites(){
    $conn = connectionToDatabase();
    if ($conn != null){

            session_start();

            $userses = $_SESSION['email'];

            $sql1 = "SELECT * FROM favorites WHERE emailFK = '$userses'";
        $result1 = $conn -> query($sql1);
        $full_response = Array();
        if ($result1->num_rows > 0)
        {
            while ($row = $result1->fetch_assoc())
            {
                $response = $row["storyidFK"];
                array_push($full_response, $response);
            }
            $full_response2 = Array();
            foreach ($full_response as $storyidFK) {
                $sql2 = "SELECT * FROM stories WHERE storyid = '$storyidFK'";
                $result2 = $conn -> query($sql2);
                if ($result2->num_rows > 0)
                {
                    $row = $result2->fetch_assoc();
                    $response2 = array("description"=>$row["description"], "emailFK"=>$row["emailFK"], "failcount"=>$row['failcount'], "horrorcount"=>$row["horrorcount"], "nutscount"=>$row["nutscount"], "sadcount"=>$row["sadcount"], "storyid"=>$row["storyid"], "storyname"=>$row["storyname"]);
                    array_push($full_response2, $response2);
                }
            }
            return $full_response2;
            $conn->close();
        }
    } else {
        $conn->close();
        return array("status"=>"COULD NOT CONNECT TO DATABASE");
    }
}

function attemptLoadComments(){
    $conn = connectionToDatabase();
    if ($conn != null){
        if(isset($_POST['user'])){
            session_start();
            $userses = $_SESSION['email'];
            $sql = "SELECT * FROM stories WHERE emailFK = '$userses' ORDER BY storyid";
        }
        else {
            $sql = "SELECT * FROM stories  ORDER BY storyid DESC";
        }
        $result = $conn->query($sql);

        $full_response = Array();
        if ($result->num_rows > 0)
        {
            while ($row = $result->fetch_assoc())
            {
                $response = array("description"=>$row["description"], "emailFK"=>$row["emailFK"], "failcount"=>$row['failcount'], "horrorcount"=>$row["horrorcount"], "nutscount"=>$row["nutscount"], "sadcount"=>$row["sadcount"], "storyid"=>$row["storyid"], "storyname"=>$row["storyname"]);
                array_push($full_response, $response);
            }
            $conn->close();
            return $full_response;
        }
    } else {
        $conn->close();
        return array("status"=>"COULD NOT CONNECT TO DATABASE");
    }
}

function attemptVoteCategory($Category, $Nombre){
    $conn = connectionToDatabase();
    if ($conn != null){
        if($Category == 'horror'){
            $sql = "UPDATE stories SET  horrorcount = horrorcount + 1 WHERE storyname='$Nombre'";
        }
        else if($Category == 'sad'){
            $sql = "UPDATE stories SET  sadcount = sadcount + 1 WHERE storyname='$Nombre'";
        }
        else if($Category == 'nuts'){
            $sql = "UPDATE stories SET  nutscount = nutscount + 1 WHERE storyname='$Nombre'";
        }
        else if($Category == 'fail'){
            $sql = "UPDATE stories SET  failcount = failcount + 1 WHERE storyname='$Nombre'";
        }

        $result = $conn->query($sql);
        if (mysqli_query($conn, $sql)) {
            $conn->close();
            return array("status" => "SUCCESS");
        } else {
            $conn->close();
            return array("status" => "IT WAS NOT POSSIBLE TO POST THE COMMENT");
        }

    } else {
        $conn->close();
        return array("status"=>"COULD NOT CONNECT TO DATABASE");
    }
}

function attemptGetUser(){
    $conn = connectionToDataBase();
    if($conn != null){
        session_start();
        $email = $_SESSION["email"];
        $sql = "SELECT * FROM users WHERE email = '$email'";
        $result = $conn->query($sql);

        $full_response = Array();
        if ($result->num_rows > 0)
        {
            while ($row = $result->fetch_assoc())
            {
                $response = array("fname"=>$row["fname"], "lname"=>$row["lname"], "email"=>$row['email'], "username"=>$row["username"], "biography"=>$row["biography"]);
                array_push($full_response, $response);
            }
            $conn->close();
            return $full_response;
        }
    } else {
        $conn->close();
        return array("status"=>"COULD NOT CONNECT TO DATABASE");
    }
}

function attemptTopTen($category){
    $conn = connectionToDatabase();
    $tablename = $category + 'count';
    if ($conn != null){
        if($category == 'horror') {
            $sql = "SELECT storyname, description, emailFK, horrorcount FROM stories ORDER BY horrorcount DESC";
        }
        else if($category == 'sad') {
            $sql = "SELECT storyname, description, emailFK, sadcount FROM stories ORDER BY sadcount DESC";
        }
        else if($category == 'fail') {
            $sql = "SELECT storyname, description, emailFK, failcount FROM stories ORDER BY failcount DESC";
        }
        else if($category == 'nuts') {
            $sql = "SELECT storyname, description, emailFK, nutscount FROM stories ORDER BY nutscount DESC";
        }

        $result = $conn->query($sql);

        $full_response = Array();
        if ($result->num_rows > 0)
        {
            if($category == 'horror') {
                while ($row = $result->fetch_assoc())
                {
                    $response = array("description"=>$row["description"], "emailFK"=>$row["emailFK"], "counts"=>$row['horrorcount'], "storyname"=>$row["storyname"]);
                    array_push($full_response, $response);
                }
            }
            else if($category == 'sad') {
                while ($row = $result->fetch_assoc())
                {
                    $response = array("description"=>$row["description"], "emailFK"=>$row["emailFK"], "counts"=>$row['sadcount'], "storyname"=>$row["storyname"]);
                    array_push($full_response, $response);
                }
            }
            else if($category == 'fail') {
                while ($row = $result->fetch_assoc())
                {
                    $response = array("description"=>$row["description"], "emailFK"=>$row["emailFK"], "counts"=>$row['failcount'], "storyname"=>$row["storyname"]);
                    array_push($full_response, $response);
                }
            }
            else if($category == 'nuts') {
                while ($row = $result->fetch_assoc())
                {
                    $response = array("description"=>$row["description"], "emailFK"=>$row["emailFK"], "counts"=>$row['nutscount'], "storyname"=>$row["storyname"]);
                    array_push($full_response, $response);
                }
            }
            $conn->close();
            return $full_response;
        }
    } else {
        $conn->close();
        return array("status"=>"COULD NOT CONNECT TO DATABASE");
    }
}

function attemptAddComment($email, $passwrd){
    $conn = connectionToDatabase();
    if ($conn != null){
        $sql = "SELECT fName, lName, email, passwrd FROM users WHERE email = '$email'";
        $result = $conn->query($sql);
        if ($result->num_rows < 1)
        {
            $conn->close();
            return array("status"=>"Bad credentials provided.");
        }
        else
        {
            $row = $result->fetch_assoc();
            if( $passwrd == decryptPassword( $row['passwrd'])) {
                $email = $row["email"];
                $comment = $_POST['comment'];
                $sql = "INSERT INTO comments (emailFK, comentario) VALUES ('$email', '$comment')";
                if (mysqli_query($conn, $sql)) {
                    $conn->close();
                    return array("status" => "SUCCESS", "email" => $email);
                } else {
                    $conn->close();
                    return array("status" => "IT WAS NOT POSSIBLE TO POST THE COMMENT");
                }
            }
            else {
                $conn->close();
                return array("status" => "INCORRECT PASSWORD");
            }
        }
    } else {
        $conn->close();
        return array("status"=>"COULD NOT CONNECT TO DATABASE");
    }
}

function attemptAddStory($email, $passwrd){
    $conn = connectionToDatabase();
    if ($conn != null){
        $sql = "SELECT fName, lName, email, passwrd FROM users WHERE email = '$email'";
        $result = $conn->query($sql);
        if ($result->num_rows < 1)
        {
            $conn->close();
            return array("status"=>"Bad credentials provided.");
        }
        else
        {
            $row = $result->fetch_assoc();
            if( $passwrd == decryptPassword( $row['passwrd'])) {
                $email = $row["email"];
                $description = $_POST['description'];
                $storyname = $_POST['storyname'];
                $sql = "INSERT INTO stories (emailFK, description,failcount,horrorcount,nutscount,sadcount,storyname) 
                        VALUES ('$email', '$description',0,0,0,0,'$storyname')";
                if (mysqli_query($conn, $sql)) {
                    $conn->close();
                    return array("status" => "SUCCESS", "email" => $email);
                } else {
                    $conn->close();
                    return array("status" => "IT WAS NOT POSSIBLE TO POST THE COMMENT");
                }
            }
            else {
                $conn->close();
                return array("status" => "INCORRECT PASSWORD");
            }
        }
    } else {
        $conn->close();
        return array("status"=>"COULD NOT CONNECT TO DATABASE");
    }
}
?>