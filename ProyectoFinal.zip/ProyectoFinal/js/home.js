/**
 * Created by DI_GO on 16/11/2016.
 */
function ChecaSession() {
    var jsonData = {
        "action" :"CHECKSESSION"
    };
    $.ajax({
        data : jsonData,
        type : "POST",
        dataType : "json",
        contentType : "application/x-www-form-urlencoded",
        url: 'data/applicationlayer.php'
    })
        .done(function(response) {
            // Open login modal if there is no session
            console.log(response);
            if (response == 0) {
                $("#logged-in").hide();
                var as = $("#menu").children();
                as[3].style.display = "block";
                as[4].style.display = "block";
                as[2].style.display = "none";
                as[1].style.display = "none";
                $("#categoriesbttons").hide();
                $("#btnStorySubmit").hide();
                $("#btnLogIn").show();
            }
            else {
                var respuesta = response;
                $("#logged-in").show();
                $("#username-navbar").text(respuesta.fname + " " + respuesta.lname);
                var as = $("#menu").children();
                as[3].style.display = "none";
                as[4].style.display = "none";
                as[2].style.display = "block";
                as[1].style.display = "block";
                $("#btnStorySubmit").show();
                $("#btnLogIn").hide();
                $("#categoriesbttons").show();
            }
        })
}

function LogOut(){
    $("#logout-btn").click(function() {
        $.ajax({
            url: 'data/applicationlayer.php'
        })
            .done(function() {
                alert("You are not longer logged in!");
                location.replace("index.html");
                location.reload();
            })
    })
}

function GetStories() {
    var jsonData = {
        "action" : "LOAD"
    };
    $.ajax({
        url : "data/applicationlayer.php",
        dataType : "json",
        type : "POST",
        data : jsonData,
        success : function(data) {
            var newHTMLContent = "";
            var clone = $("#StoryClone").clone();
            for(i = 0; (i < data.length && i < 10); i++)
            {
                newHTMLContent = clone.clone();
                newHTMLContent.removeAttr("id","StoryClone");
                newHTMLContent.attr("class","StoryNoClone");
                newHTMLContent.find("#StoryNam").text(data[i].storyname);
                newHTMLContent.find("#Story").text(data[i].description);
                newHTMLContent.find("#StoryTeller").text(data[i].emailFK);
                var arrLabels= newHTMLContent.find("#categoriesbttons").find("label");
                arrLabels[0].innerHTML = data[i].failcount;
                arrLabels[1].innerHTML = data[i].horrorcount;
                arrLabels[2].innerHTML = data[i].sadcount;
                arrLabels[3].innerHTML = data[i].nutscount;
                console.log(arrLabels);
                $("#StorySection").append(newHTMLContent);
                $("#StorySection").append("<br>");
            }
            $("#StoryClone").hide();
        },
        error: function (errorMessage) {
            alert(errorMessage.responseText);
        }
    });
}

function CategoryVote () {
    $("#StorySection").on("click", ".btnhorror", function(e) {
        var target = $(e.target);
        var padre = target.parent().parent();
        var nombre = padre.find("#StoryNam").text();
        console.log(nombre);
        var jsonData = {
            "action" : "VOTE",
            "category" : "horror",
            "nombre" : nombre
        };
        $.ajax({
            url : "data/applicationlayer.php",
            dataType : "json",
            type : "POST",
            data : jsonData,
            success : function(data) {
                location.reload();
            },
            error: function (errorMessage) {
                alert(errorMessage.responseText);
            }
        });
    });

    $("#StorySection").on("click", ".btnsad", function(e) {
        var target = $(e.target);
        var padre = target.parent().parent();
        var nombre = padre.find("#StoryNam").text();
        console.log(nombre);
        var jsonData = {
            "action" : "VOTE",
            "category" : "sad",
            "nombre" : nombre
        };
        $.ajax({
            url : "data/applicationlayer.php",
            dataType : "json",
            type : "POST",
            data : jsonData,
            success : function(data) {
                location.reload();
            },
            error: function (errorMessage) {
                alert(errorMessage.responseText);
            }
        });
    });
    $("#StorySection").on("click", ".btncrazy", function(e) {
        console.log("enotra");
        var target = $(e.target);
        var padre = target.parent().parent();
        var nombre = padre.find("#StoryNam").text();
        console.log(nombre);
        var jsonData = {
            "action" : "VOTE",
            "category" : "nuts",
            "nombre" : nombre
        };
        $.ajax({
            url : "data/applicationlayer.php",
            dataType : "json",
            type : "POST",
            data : jsonData,
            success : function(data) {
                location.reload();
            },
            error: function (errorMessage) {
                alert(errorMessage.responseText);
            }
        });
    });

    $("#StorySection").on("click", ".btnfail", function(e) {
        var target = $(e.target);
        var padre = target.parent().parent();
        var nombre = padre.find("#StoryNam").text();
        console.log(nombre);
        var jsonData = {
            "action" : "VOTE",
            "category" : "fail",
            "nombre" : nombre
        };
        $.ajax({
            url : "data/applicationlayer.php",
            dataType : "json",
            type : "POST",
            data : jsonData,
            success : function(data) {
                location.reload();
            },
            error: function (errorMessage) {
                alert(errorMessage.responseText);
            }
        });
    });

}


function isEmpty(value) {
    return value.trim() == "";
}

function TopTen() {
    var jsonData = {
        "action" : "TOP",
        "category" : "horror"
    };
    $.ajax({
        url : "data/applicationlayer.php",
        dataType : "json",
        type : "POST",
        data : jsonData,
        success : function(data) {
            var newHTMLContent = "";
            var clone = $("#horrorclone").clone();
            for(i = 0; (i < data.length )&&(i < 10); i++)
            {
                newHTMLContent = clone.clone();
                newHTMLContent.removeAttr("id","horrorclone");
                newHTMLContent.attr("class","horrorNoclone");
                var spans = newHTMLContent.children();
                spans[0].innerHTML = '#' + (i+1) + data[i].storyname;
                spans[1].innerHTML = 'created by: ' + data[i].emailFK;
                spans[2].innerHTML = "Votes:" + data[i].counts;
                console.log(data[i].counts);
                newHTMLContent.innerHTML = spans;
                $("#horrorfield").append(newHTMLContent);
            }
            $("#horrorclone").hide();
        },
        error: function (errorMessage) {
            alert(errorMessage.responseText);
        }
    });
    var jsonData = {
        "action" : "TOP",
        "category" : "sad"
    };
    $.ajax({
        url : "data/applicationlayer.php",
        dataType : "json",
        type : "POST",
        data : jsonData,
        success : function(data) {
            var newHTMLContent = "";
            var clone = $("#sadclone").clone();
            for(i = 0; (i < data.length )&&(i < 10); i++)
            {
                newHTMLContent = clone.clone();
                newHTMLContent.removeAttr("id","sadclone");
                newHTMLContent.attr("class","sadNoclone");
                var spans = newHTMLContent.children();
                spans[0].innerHTML = '#' + (i+1) + data[i].storyname;
                spans[1].innerHTML = 'created by: ' + data[i].emailFK;
                spans[2].innerHTML = "Votes:" + data[i].counts;
                console.log(data[i].counts);
                newHTMLContent.innerHTML = spans;
                $("#sadfield").append(newHTMLContent);
            }
            $("#sadclone").hide();
        },
        error: function (errorMessage) {
            alert(errorMessage.responseText);
        }
    });
    var jsonData = {
        "action" : "TOP",
        "category" : "nuts"
    };
    $.ajax({
        url : "data/applicationlayer.php",
        dataType : "json",
        type : "POST",
        data : jsonData,
        success : function(data) {
            var newHTMLContent = "";
            var clone = $("#crazyclone").clone();
            for(i = 0; (i < data.length )&&(i < 10); i++)
            {
                newHTMLContent = clone.clone();
                newHTMLContent.removeAttr("id","crazyclone");
                newHTMLContent.attr("class","crazyNoclone");
                var spans = newHTMLContent.children();
                spans[0].innerHTML = '#' + (i+1) + data[i].storyname;
                spans[1].innerHTML = 'created by: ' + data[i].emailFK;
                spans[2].innerHTML = "Votes:" + data[i].counts;
                console.log(data[i].counts);
                newHTMLContent.innerHTML = spans;
                $("#crazyfield").append(newHTMLContent);
            }
            $("#crazyclone").hide();
        },
        error: function (errorMessage) {
            alert(errorMessage.responseText);
        }
    });
    var jsonData = {
        "action" : "TOP",
        "category" : "fail"
    };
    $.ajax({
        url : "data/applicationlayer.php",
        dataType : "json",
        type : "POST",
        data : jsonData,
        success : function(data) {
            var newHTMLContent = "";
            var clone = $("#failclone").clone();
            for(i = 0; (i < data.length )&&(i < 10); i++)
            {
                newHTMLContent = clone.clone();
                newHTMLContent.removeAttr("id","failclone");
                newHTMLContent.attr("class","failNoclone");
                var spans = newHTMLContent.children();
                spans[0].innerHTML = '#' + (i+1) + data[i].storyname;
                spans[1].innerHTML = 'created by: ' + data[i].emailFK;
                spans[2].innerHTML = "Votes:" + data[i].counts;
                console.log(data[i].counts);
                newHTMLContent.innerHTML = spans;
                $("#failfield").append(newHTMLContent);
            }
            $("#failclone").hide();
        },
        error: function (errorMessage) {
            alert(errorMessage.responseText);
        }
    });
}

function ChoseFavorite () {
    $("#StorySection").on("click", ".btnfav", function (e) {
        console.log("entro");
        var target = $(e.target);
        var padre = target.parent().parent();
        var nombre = padre.find("#StoryNam").text();
        console.log(nombre);
        var jsonData = {
            "action": "FAV",
            "name": nombre
        };
        $.ajax({
            url: "data/applicationlayer.php",
            dataType: "json",
            type: "POST",
            data: jsonData,
            success: function (data) {
                alert(data.message);
            },
            error: function (errorMessage) {
                alert(errorMessage.responseText);
            }
        });
    });
}

function PostStory() {
    $("#btnStorySubmit").click(function() {
        var feedbackComplete = true;
        var description = $('#tfstory').val();
        var storyname = $('#tfstoryname').val();
        if(isEmpty(description)) {
            alert("Please, write a story.");
            feedbackComplete = false;
        }
        if(isEmpty(storyname)) {
            alert("Please, write a name for your story.");
            feedbackComplete = false;
        }
        var jsonData = {
            "action": "STORY",
            "session": true,
            "storyname" : storyname,
            'description': description
        };
        console.log
        if(feedbackComplete) {
            $.ajax({
                url: "data/applicationlayer.php",
                type: "POST",
                data: jsonData,
                dataType: "json",
                contentType: "application/x-www-form-urlencoded",
                success: function (jsonResponse) {
                    alert("New Story of " + jsonResponse.email);
                    location.reload();
                    $('#tfstoryname').val("");
                    $('#tfstory').val("");
                },
                error: function (jsonData) {
                    console.log(jsonData);
                    alert(jsonData.responseText);
                }
            });
        }
    });
    $("#btnLogIn").click(function () {
        location.replace("LogIn.html");
    });
}



$(document).ready(function() {
    ChecaSession();
    LogOut();
    GetStories();
    PostStory();
    TopTen();
    CategoryVote();
    ChoseFavorite();
});