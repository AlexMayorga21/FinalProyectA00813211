/**
 * Created by DI_GO on 16/11/2016.
 */
function ChecaSession() {
    var jsonData = {
        "action" :"CHECKSESSION"
    };
    $.ajax({
        data : jsonData,
        type : "POST",
        dataType : "json",
        contentType : "application/x-www-form-urlencoded",
        url: 'data/applicationlayer.php'
    })
        .done(function(response) {
            // Open login modal if there is no session
            console.log(response);
            if (response == 0) {
                $("#logged-in").hide();
                var as = $("#menu").children();
                as[3].style.display = "block";
                as[4].style.display = "block";
                as[2].style.display = "none";
                as[1].style.display = "none";
            }
            else {
                var respuesta = response;
                $("#logged-in").show();
                $("#username-navbar").text(respuesta.fname + " " + respuesta.lname);
                var as = $("#menu").children();
                as[3].style.display = "none";
                as[4].style.display = "none";
                as[2].style.display = "block";
                as[1].style.display = "block";
            }
        })
}

function GetFavs() {
    var jsonData = {
        "action" : "LOADFAVS"
    };
    $.ajax({
        url : "data/applicationlayer.php",
        dataType : "json",
        type : "POST",
        data : jsonData,
        success : function(data) {
            console.log(data);
            var newHTMLContent = "";
            var clone = $("#StoryClone").clone();
            for(i = 0; (i < data.length && i < 10); i++)
            {
                newHTMLContent = clone.clone();
                newHTMLContent.removeAttr("id","StoryClone");
                newHTMLContent.attr("class","StoryNoClone");
                newHTMLContent.find("#StoryNam").text(data[i].storyname);
                newHTMLContent.find("#Story").text(data[i].description);
                newHTMLContent.find("#StoryTeller").text(data[i].emailFK);
                $("#StorySection").append(newHTMLContent);
                $("#StorySection").append("<br>");
            }
            $("#StoryClone").hide();
        },
        error: function (errorMessage) {
            alert(errorMessage.responseText);
        }
    });
}

function LogOut(){
    $("#logout-btn").click(function() {
        $.ajax({
            url: 'data/applicationlayer.php'
        })
            .done(function() {
                alert("You are not longer logged in!");
                location.replace("index.html");
                location.reload();
            })
    })
}

$(document).ready(function() {
    ChecaSession();
    GetFavs();
    LogOut();
});